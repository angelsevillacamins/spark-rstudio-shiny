library(shiny)
library(datasets)

#Spark server initialization
library(SparkR, lib.loc = c(file.path(Sys.getenv("SPARK_HOME"), "R", "lib")))

sparkR.stop()
sc <- sparkR.init(master = "spark://master:7077",
                  sparkEnvir = list(spark.executor.memory="4g"))
sqlContext <- sparkRSQL.init(sc)

#Transfrom mtcars into DataFrame format
DF <- createDataFrame(sqlContext, mtcars)
cache(DF)

shinyServer(function(input, output,session) {

  # Compute the formula text in a reactive expression
  formulaText <- reactive({
    if (is.null(input$variables)) return("mpg ~ wt")
    else return(paste("mpg ~ wt",
                      paste(input$variables, collapse = " + ")
                      , sep = " + "))
  })

  # Compute the GLM model
  model <- eventReactive(input$regression, {
     SparkR::glm(as.formula(formulaText()),
                 data = DF, family = "gaussian")
  })

  # Return the formula text for printing
  output$formula <- renderText({
    formulaText()
  })

  # Return model coefficients for printing
  output$model <- renderTable({
    data.frame(summary(model())$coefficients)
  })

  # Stop SparkR after closing the session
  session$onSessionEnded(function() {
    sparkR.stop()
  })
})
