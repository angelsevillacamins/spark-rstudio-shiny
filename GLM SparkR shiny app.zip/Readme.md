This application is able to fit a generalized linear model (GLM) in SparkR cluster using the mtcars data. This is formed by three-node Docker Swarm cluster with two workers and one master in [Carina](https://www.rackspace.com). Rstudio and Shiny servers are also hosted in the master node.

To use this application:

1. Select which variables should be added to the GLM with the exception of the Weight (wt). This variable is always included to avoid an empty model.

2. As a result, the model formula is showed.

3. Press the Launch regression button to fit the GLM model. The obtained parameters are presented.

4. To launch the SparkR server master UI, press the link below the Launch regression button.
